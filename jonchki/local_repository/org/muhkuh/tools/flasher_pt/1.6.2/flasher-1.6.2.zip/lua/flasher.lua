-----------------------------------------------------------------------------
--   Copyright (C) 2019 by Christoph Thelen                                --
--   doc_bacardi@users.sourceforge.net                                     --
--                                                                         --
--   This program is free software; you can redistribute it and/or modify  --
--   it under the terms of the GNU General Public License as published by  --
--   the Free Software Foundation; either version 2 of the License, or     --
--   (at your option) any later version.                                   --
--                                                                         --
--   This program is distributed in the hope that it will be useful,       --
--   but WITHOUT ANY WARRANTY; without even the implied warranty of        --
--   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         --
--   GNU General Public License for more details.                          --
--                                                                         --
--   You should have received a copy of the GNU General Public License     --
--   along with this program; if not, write to the                         --
--   Free Software Foundation, Inc.,                                       --
--   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             --
-----------------------------------------------------------------------------

local class = require 'pl.class'
local Flasher = class()


function Flasher:_init(tLog)
  self.tLog = tLog

  self.bit = require 'bit'
  self.romloader = require 'romloader'

  -----------------------------------------------------------------------------
  --                           Definitions
  -----------------------------------------------------------------------------

  self.BUS_Parflash    = 0             -- parallel flash
  self.BUS_Spi         = 1             -- serial flash on spi bus
  self.BUS_IFlash      = 2             -- internal flash
  self.BUS_SDIO        = 3             -- SD/EMMC


  self.OPERATION_MODE_Flash             = 0
  self.OPERATION_MODE_Erase             = 1
  self.OPERATION_MODE_Read              = 2
  self.OPERATION_MODE_Verify            = 3
  self.OPERATION_MODE_Checksum          = 4     -- Build a checksum over the contents of a specified area of a device.
  self.OPERATION_MODE_Detect            = 5     -- Detect a device.
  self.OPERATION_MODE_IsErased          = 6     -- Check if the specified area of a device is erased.
  self.OPERATION_MODE_GetEraseArea      = 7     -- Expand an area to the erase block borders.
  self.OPERATION_MODE_GetBoardInfo      = 8     -- Get bus and unit information.
  self.OPERATION_MODE_EasyErase         = 9     -- A combination of GetEraseArea, IsErased and Erase.
  self.OPERATION_MODE_SpiMacroPlayer    = 10    -- A debug mode to send commands to a SPI flash.


  self.MSK_SQI_CFG_IDLE_IO1_OE          = 0x01
  self.SRT_SQI_CFG_IDLE_IO1_OE          = 0
  self.MSK_SQI_CFG_IDLE_IO1_OUT         = 0x02
  self.SRT_SQI_CFG_IDLE_IO1_OUT         = 1
  self.MSK_SQI_CFG_IDLE_IO2_OE          = 0x04
  self.SRT_SQI_CFG_IDLE_IO2_OE          = 2
  self.MSK_SQI_CFG_IDLE_IO2_OUT         = 0x08
  self.SRT_SQI_CFG_IDLE_IO2_OUT         = 3
  self.MSK_SQI_CFG_IDLE_IO3_OE          = 0x10
  self.SRT_SQI_CFG_IDLE_IO3_OE          = 4
  self.MSK_SQI_CFG_IDLE_IO3_OUT         = 0x20
  self.SRT_SQI_CFG_IDLE_IO3_OUT         = 5


  self.SMC_INITIALIZE                   = 0
  self.SMC_CHIP_SELECT                  = 1
  self.SMC_EXCHANGE_DATA                = 2
  self.SMC_SEND_DATA                    = 3
  self.SMC_RECEIVE_DATA                 = 4
  self.SMC_SEND_IDLE_BYTES              = 5


  self.FLASHER_INTERFACE_VERSION        = 0x00030000


  --------------------------------------------------------------------------
  -- callback/progress functions, 
  -- read/write image, call
  --------------------------------------------------------------------------

  local this = self
  self.fnProgressDefault = function(ulCnt, ulMax) return this:default_callback_progress(ulCnt, ulMax) end
  self.fnMessageDefault = function(a, b) return this:default_callback_message(a, b) end

  self.ulProgressLastTime    = 0
  self.fProgressLastPercent  = 0
  self.ulProgressLastMax     = nil
  self.PROGRESS_STEP_PERCENT = 10
end


function Flasher:default_callback_progress(ulCnt, ulMax)
  local fPercent = math.floor(ulCnt * 100 / ulMax)
  local ulTime = os.time()
  if self.ulProgressLastMax~=ulMax or ulCnt==0 or ulCnt==ulMax or self.fProgressLastPercent-fPercent>self.PROGRESS_STEP_PERCENT or ulTime-self.ulProgressLastTime>1 then
    self.fProgressLastPercent = fPercent
    self.ulProgressLastMax = ulMax
    self.ulProgressLastTime = ulTime
    self.tLog.debug('%d%% (%d/%d)', fPercent, ulCnt, ulMax)
  end
  return true
end


function Flasher:default_callback_message(a,b)
  if type(a)=="string" and string.len(a)>0 then
    local strCnt, strMax = string.match(a, '%% ([%x%X]+)/([%x%X]+)')
    if strCnt and strMax then
      local ulCnt = tonumber(strCnt, 16)
      local ulMax = tonumber(strMax, 16)
      if ulCnt and ulMax then
        return self:default_callback_progress(ulCnt, ulMax)
      end
    else
      if string.sub(a, -1)=='\n' then
        a = string.sub(a, 1, -2)
      end
      self.tLog.debug('[netx] %s', a)
    end
  end
  return true
end

function Flasher:write_image(tPlugin, ulAddress, strData, fnCallbackProgress)
  local this = self
  fnCallbackProgress = fnCallbackProgress or self.fnProgressDefault
  return tPlugin:write_image(ulAddress, strData, fnCallbackProgress, strData:len())
end

function Flasher:read_image(tPlugin, ulAddress, ulSize, fnCallbackProgress)
  local this = self
  fnCallbackProgress = fnCallbackProgress or self.fnProgressDefault
  return tPlugin:read_image(ulAddress, ulSize, fnCallbackProgress, ulSize)
end

function Flasher:call(tPlugin, ulExecAddress, ulParameterAddress, fnCallbackMessage)
  local this = self
  fnCallbackMessage = fnCallbackMessage or self.fnMessageDefault
  return tPlugin:call(ulExecAddress, ulParameterAddress, fnCallbackMessage, 2)
end

-----------------------------------------------------------------------------
--                    Downloading the flasher
-----------------------------------------------------------------------------

-- prefix must include a trailing backslash if it's a directory
function Flasher:get_flasher_binary_path(iChiptype, strPathPrefix, fDebug)
  local strNetxName = nil
  local strDebug = fDebug and "_debug" or ""
  local strPrefix = strPathPrefix or ""

  -- First catch the unlikely case that "iChiptype" is nil.
  -- Otherwise each ROMLOADER_CHIPTYP_* which is also nil will match.
  if iChiptype==nil then
    strNetxName = nil
  elseif iChiptype==romloader.ROMLOADER_CHIPTYP_NETX500 or iChiptype==romloader.ROMLOADER_CHIPTYP_NETX100 then
    strNetxName = 'netx500'
  elseif iChiptype==romloader.ROMLOADER_CHIPTYP_NETX50 then
    strNetxName = 'netx50'
  elseif iChiptype==romloader.ROMLOADER_CHIPTYP_NETX10 then
    strNetxName = 'netx10'
  elseif iChiptype==romloader.ROMLOADER_CHIPTYP_NETX56 or iChiptype==romloader.ROMLOADER_CHIPTYP_NETX56B then
    strNetxName = 'netx56'
  elseif iChiptype==romloader.ROMLOADER_CHIPTYP_NETX4000_RELAXED or iChiptype==romloader.ROMLOADER_CHIPTYP_NETX4000_FULL or iChiptype==romloader.ROMLOADER_CHIPTYP_NETX4100_SMALL then
    strNetxName = 'netx4000'
  elseif iChiptype==romloader.ROMLOADER_CHIPTYP_NETX90_MPW then
    strNetxName = 'netx90_mpw'
  elseif iChiptype==romloader.ROMLOADER_CHIPTYP_NETX90 or iChiptype==romloader.ROMLOADER_CHIPTYP_NETX90B then
    strNetxName = 'netx90'
  elseif iChiptype==romloader.ROMLOADER_CHIPTYP_NETIOLA or iChiptype==romloader.ROMLOADER_CHIPTYP_NETIOLB then
    strNetxName = 'netiol'
  end
  if not strNetxName then
    error("Unknown chiptyp! " .. tostring(iChiptype))
  end

  local strPath = strPrefix .. "flasher_" .. strNetxName .. strDebug .. ".bin"
  return strPath
end


function Flasher:get_dword(strData, ulOffset)
  return strData:byte(ulOffset) + strData:byte(ulOffset+1)*0x00000100 + strData:byte(ulOffset+2)*0x00010000 + strData:byte(ulOffset+3)*0x01000000
end


-- Extract header information from the flasher binary
-- information about code/exec/buffer addresses
function Flasher:get_flasher_binary_attributes(strData)
  local aAttr = {}

  -- Get the load and exec address from the binary.
  aAttr.ulLoadAddress = self:get_dword(strData, 32 + 1)
  aAttr.ulExecAddress = self:get_dword(strData, 36 + 1)
  aAttr.ulParameter   = self:get_dword(strData, 40 + 1)
  aAttr.ulDeviceDesc  = self:get_dword(strData, 44 + 1)
  aAttr.ulBufferAdr   = self:get_dword(strData, 48 + 1)
  aAttr.ulBufferEnd   = self:get_dword(strData, 52 + 1)
  aAttr.ulBufferLen   = aAttr.ulBufferEnd - aAttr.ulBufferAdr

  -- Show the information:
  print(string.format("parameter:          0x%08x", aAttr.ulParameter))
  print(string.format("device description: 0x%08x", aAttr.ulDeviceDesc))
  print(string.format("buffer start:       0x%08x", aAttr.ulBufferAdr))
  print(string.format("buffer end:         0x%08x", aAttr.ulBufferEnd))
  print(string.format("buffer size:        0x%08x", aAttr.ulBufferLen))

  return aAttr
end


-- download binary to netX. Extracts and returns the header information.
-- Download a netx binary.
-- Returns the binary's attribute list.
function Flasher:download_netx_binary(tPlugin, strData, fnCallbackProgress)
  local aAttr = self:get_flasher_binary_attributes(strData)
  print(string.format("downloading to 0x%08x", aAttr.ulLoadAddress))
  self:write_image(tPlugin, aAttr.ulLoadAddress, strData, fnCallbackProgress)
  -- tPlugin:write_image(aAttr.ulLoadAddress, strData, fnCallbackProgress, string.len(strData))
  
  return aAttr
end

-- Download flasher.
-- - Load the flasher binary according to the chip type the
--    plugin is connected to
-- - Extract header information from the flasher
--   (static information about code/exec/buffer addresses)
-- - Download the flasher to the specified address

-- tPlugin plugin object with an active connection
-- strPrefix path to flasher binaries
-- fnCallbackProgress is a function to call while downloading the flasher.
--   This parameter is optional. The default is to print a simple progress
--   message to stdout.

--   The function must accept 2 parameters:
--    1) the number of processed bytes
--    2) the total number of bytes
--   The function must return one boolean. A value of 'true' continues the
--   download operation, while a value of 'false' cancels the download.
--
-- Returns flasher attributes (parameter address, buffer address etc.)



function Flasher:download(tPlugin, strPrefix, fnCallbackProgress)
  local iChiptype = tPlugin:GetChiptyp()
  local fDebug = false
  local strPath = self:get_flasher_binary_path(iChiptype, strPrefix, fDebug)
  local tFile, strMsg = io.open(strPath, 'rb')
  if tFile==nil then
    error(string.format('Failed to open file "%s" for reading: %s', strPath, strMsg))
  end
  local strFlasherBin = tFile:read('*a')
  tFile:close()

  local aAttr = self:get_flasher_binary_attributes(strFlasherBin)
  aAttr.strBinaryName = strFlasherBin

  print(string.format("downloading to 0x%08x", aAttr.ulLoadAddress))
  self:write_image(tPlugin, aAttr.ulLoadAddress, strFlasherBin, fnCallbackProgress)

  return aAttr
end


-- set the buffer area (when using SDRAM as a buffer, for instance)
function Flasher:set_buffer_area(aAttr, ulBufferAdr, ulBufferLen)
  aAttr.ulBufferAdr   = ulBufferAdr
  aAttr.ulBufferEnd   = ulBufferAdr + ulBufferLen
  aAttr.ulBufferLen   = ulBufferLen
end



-----------------------------------------------------------------------------
--                    Calling the flasher
-----------------------------------------------------------------------------



-- download parameters to netX
function Flasher:set_parameterblock(tPlugin, ulAddress, aulParameters, fnCallbackProgress)
  local bit = self.bit
  local strBin = ""
    for i,v in ipairs(aulParameters) do
      strBin = strBin .. string.char( bit.band(v,0xff), bit.band(bit.rshift(v,8),0xff), bit.band(bit.rshift(v,16),0xff), bit.band(bit.rshift(v,24),0xff) )
    end
  self:write_image(tPlugin, ulAddress, strBin, fnCallbackProgress) 
end

-- Stores parameters in netX memory, calls the flasher and returns the result value
-- 0 = success, 1 = failure
function Flasher:callFlasher(tPlugin, aAttr, aulParams, fnCallbackMessage, fnCallbackProgress)
  fnCallbackMessage = fnCallbackMessage or self.fnMessageDefault
  fnCallbackProgress = fnCallbackProgress or self.fnProgressDefault

  -- set the parameters
  local aulParameter = {}
  aulParameter[1] = 0xffffffff                 -- placeholder for return vallue, will be 0 if ok
  aulParameter[2] = aAttr.ulParameter+0x0c     -- pointer to actual parameters
  aulParameter[3] = 0x00000000                 -- unused
                                             -- extended parameters
  aulParameter[4] = self.FLASHER_INTERFACE_VERSION  -- set the parameter version
  for i=1, #aulParams do
    aulParameter[4+i] = aulParams[i]     -- actual parameters for the particular function
  end

  self:set_parameterblock(tPlugin, aAttr.ulParameter, aulParameter, fnCallbackProgress)

  -- call
  self:call(tPlugin, aAttr.ulExecAddress, aAttr.ulParameter, fnCallbackMessage) 

  -- get the return value (ok/failed)
  -- any further return values must be read by the calling function
  ulValue = tPlugin:read_data32(aAttr.ulParameter+0x00)
  print(string.format("call finished with result 0x%08x", ulValue))
  return ulValue
end


-----------------------------------------------------------------------------
--                  Detecting flash and getting device info
-----------------------------------------------------------------------------


-- get "static" information about the buses, depending on the chip type:
-- SRAM bus parflash, extension bus parflash, SPI serial flash, SQI serial flash
function Flasher:getInfoBlock(tPlugin, aAttr, ulBusIdx, ulUnitIdx, fnCallbackMessage, fnCallbackProgress)
  local aResult = nil

  local aulParameter = 
  {
    self.OPERATION_MODE_GetBoardInfo,      -- operation mode: get board info
    ulBusIdx,
    ulUnitIdx,
    aAttr.ulBufferAdr,
    aAttr.ulBufferLen
  }

  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)

  if ulValue==0 then
    -- Get the size of the board description.
    local sizInfoMax = tPlugin:read_data32(aAttr.ulParameter+0x08)
    if sizInfoMax>0 then
      -- Get the board information.
      strInfo = self:read_image(tPlugin, aAttr.ulBufferAdr, sizInfoMax, fnCallbackProgress)

      -- Get the number of entries.
      local sizEntryNum = strInfo:byte(1)
      aResult = {}
      -- Loop over all entries.
      strNames = strInfo:sub(2)
      for strIdx,strName in string.gmatch(strNames, "(.)([^%z]+)%z") do
        table.insert(aResult, { iIdx=strIdx:byte(1), strName=strName })
      end
    end
  end

  return aResult
end


function Flasher:getBoardInfo(tPlugin, aAttr, fnCallbackMessage, fnCallbackProgress)
  -- Get the bus infos.
  local aBoardInfo = self:getInfoBlock(tPlugin, aAttr, 0xffffffff, 0xffffffff, fnCallbackMessage, fnCallbackProgress)
  for iCnt,aBusInfo in ipairs(aBoardInfo) do
    -- Get the unit info.
    local aUnitInfo = self:getInfoBlock(tPlugin, aAttr, aBusInfo.iIdx, 0xffffffff, fnCallbackMessage, fnCallbackProgress)
    aBusInfo.aUnitInfo = aUnitInfo
  end

  return aBoardInfo
end



-- check if a device is available on tBus/ulUnit/ulChipSelect
function Flasher:detect(tPlugin, aAttr, tBus, ulUnit, ulChipSelect, fnCallbackMessage, fnCallbackProgress, atParameter)
  local aulParameter
  atParameter = atParameter or {}

  if tBus==self.BUS_Spi then
    -- Set the initial SPI speed. The default is 1000kHz (1MHz).
    local ulInitialSpeed = atParameter.ulInitialSpeed
    ulInitialSpeed = ulInitialSpeed or 1000

    -- Set the maximum SPI speed. The default is 25000kHz (25MHz).
    local ulMaximumSpeed = atParameter.ulMaximumSpeed
    ulMaximumSpeed = ulMaximumSpeed or 25000

    -- Set the idle configuration. The default is all lines driving 1.
    local ulIdleCfg = atParameter.ulIdleCfg
    ulIdleCfg = ulIdleCfg or (self.MSK_SQI_CFG_IDLE_IO1_OE + self.MSK_SQI_CFG_IDLE_IO1_OUT
                            + self.MSK_SQI_CFG_IDLE_IO2_OE + self.MSK_SQI_CFG_IDLE_IO2_OUT
                            + self.MSK_SQI_CFG_IDLE_IO3_OE + self.MSK_SQI_CFG_IDLE_IO3_OUT)

    -- Set the SPI mode. The default is 3.
    local ulSpiMode = atParameter.ulSpiMode
    ulSpiMode = ulSpiMode or 3

    -- Set the MMIO configuration. The default is 0xffffffff (no MMIO pins).
    local ulMmioConfiguration = atParameter.ulMmioConfiguration
    ulMmioConfiguration = ulMmioConfiguration or 0xffffffff

    aulParameter =
    {
      self.OPERATION_MODE_Detect,           -- operation mode: detect
      tBus,                                 -- the bus
      ulUnit,                               -- unit
      ulChipSelect,                         -- chip select
      ulInitialSpeed,                       -- initial speed in kHz
      ulMaximumSpeed,                       -- maximum allowed speed in kHz
      ulIdleCfg,                            -- idle configuration
      ulSpiMode,                            -- mode
      ulMmioConfiguration,                  -- MMIO configuration
      aAttr.ulDeviceDesc                    -- data block for the device description
    }
  elseif tBus==self.BUS_Parflash then
    -- Set the allowed bus widths. This parameter is not used yet.
    local ulAllowedBusWidths = atParameter.ulAllowedBusWidths
    ulAllowedBusWidths = ulAllowedBusWidths or 0

    aulParameter =
    {
      self.OPERATION_MODE_Detect,           -- operation mode: detect
      tBus,                                 -- the bus
      ulUnit,                               -- unit
      ulChipSelect,                         -- chip select
      ulAllowedBusWidths,                   -- the allowed bus widths
      0,                                    -- reserved
      0,                                    -- reserved
      0,                                    -- reserved
      0,                                    -- reserved
      aAttr.ulDeviceDesc                    -- data block for the device description
    }
  elseif tBus==self.BUS_IFlash then
    aulParameter =
    {
      self.OPERATION_MODE_Detect,           -- operation mode: detect
      tBus,                                 -- the bus
      ulUnit,                               -- unit
      ulChipSelect,                         -- chip select
      0,                                    -- reserved
      0,                                    -- reserved
      0,                                    -- reserved
      0,                                    -- reserved
      0,                                    -- reserved
      aAttr.ulDeviceDesc                    -- data block for the device description
    }
  elseif tBus==self.BUS_SDIO then
    aulParameter = {
      self.OPERATION_MODE_Detect,           -- operation mode: detect
      tBus,                                 -- the bus
      0,                                    -- unit
      0,                                    -- chip select
      0,                                    -- reserved
      0,                                    -- reserved
      0,                                    -- reserved
      0,                                    -- reserved
      0,                                    -- reserved
      aAttr.ulDeviceDesc                    -- data block for the device description
    }

  else
    error("Unknown bus: " .. tostring(tBus))
  end

  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  return ulValue == 0
end



-- read device descriptor after detect (debugging)
function Flasher:readDeviceDescriptor(tPlugin, aAttr, fnCallbackProgress)
  -- check the device description
  local strDevDesc
  local ulSize
  local ulVersion

  local ulValue = tPlugin:read_data32(aAttr.ulDeviceDesc)
  if ulValue==0 then
    print("the device desription is not valid, nothing detected.")
  else

    -- get the size of the returned data
    ulSize = tPlugin:read_data32(aAttr.ulDeviceDesc+0x04)
    if ulSize<16 then
      print("the device description claims to be valid, but has a strange size.")
    else
      -- read the interface version of the returned data
      ulVersion = tPlugin:read_data32(aAttr.ulDeviceDesc+0x08)
      if ulVersion~=self.FLASHER_INTERFACE_VERSION then
        -- the version does not match the expected value
        print(string.format("the device description has a strange interface version."))
      else
        -- get the device description
        strDevDesc = self:read_image(tPlugin, aAttr.ulDeviceDesc, ulSize, fnCallbackProgress)
      end
    end
  end

  return strDevDesc
end


function Flasher:getDeviceId(tPlugin, aAttr, fnCallbackProgress)
  -- Read the flash device descriptor.
  local strDeviceDescriptor = self:readDeviceDescriptor(tPlugin, aAttr, fnCallbackProgress)
  if strDeviceDescriptor==nil then
    error("Failed to read the flash device descriptor!")
  end

  strDeviceId = nil
  if tBus==self.BUS_Spi then
    -- Extract the flash ID.
    local iIdxStart = 16+0+0 + 1
    local iIdxEnd = iIdxStart
    local iIdxMax = iIdxStart + 21 + 1
    while iIdxEnd<iIdxMax and string.byte(strDeviceDescriptor, iIdxEnd)~=0 do
      iIdxEnd = iIdxEnd + 1
    end
    if iIdxEnd>iIdxStart then
      strDeviceId = string.sub(strDeviceDescriptor, iIdxStart, iIdxEnd-1)
    end
  else
    error("The device ID can not yet be retrieved for parallel flashes.")
  end

  return strDeviceId
end



---------------------------------------------------------------------------------
-- The following functions assume that detect has been run and there is a
-- valid device description in the memory.

-- ulStartAddr, ulEndAddr are offsets in the flash device.
-- ulDataAddress is the absolute address of the  buffer.
---------------------------------------------------------------------------------

-- Writes data which has been loaded into the buffer at ulDataAddress to ulStartAddr in the flash.
function Flasher:flash(tPlugin, aAttr, ulStartAdr, ulDataByteSize, ulDataAddress, fnCallbackMessage, fnCallbackProgress)
  local aulParameter =
  {
    self.OPERATION_MODE_Flash,
    aAttr.ulDeviceDesc,
    ulStartAdr,
    ulDataByteSize,
    ulDataAddress
  }
  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  return ulValue == 0
end

-- Reads data from flash to RAM
function Flasher:read(tPlugin, aAttr, ulFlashStartOffset, ulFlashEndOffset, ulBufferAddress, fnCallbackMessage, fnCallbackProgress)
  local aulParameter =
  {
    self.OPERATION_MODE_Read,
    aAttr.ulDeviceDesc,
    ulFlashStartOffset,
    ulFlashEndOffset,
    ulBufferAddress
  }
  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  return ulValue == 0
end


-- Compares data in flash to RAM
function Flasher:verify(tPlugin, aAttr, ulFlashStartOffset, ulFlashEndOffset, ulBufferAddress, fnCallbackMessage, fnCallbackProgress)
  local fEqual = false
  local aulParameter =
  {
    self.OPERATION_MODE_Verify,
    aAttr.ulDeviceDesc,
    ulFlashStartOffset,
    ulFlashEndOffset,
    ulBufferAddress
  }
  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)

  if ulValue==0 then
    ulValue = tPlugin:read_data32(aAttr.ulParameter+0x08)
    fEqual = (ulValue==0)
  end

  return fEqual
end


-- Computes the SHA1 hash over data in the flash.
function Flasher:hash(tPlugin, aAttr, ulFlashStartOffset, ulFlashEndOffset, fnCallbackMessage, fnCallbackProgress)
  local strHashBin = nil
  local aulParameter =
  {
    self.OPERATION_MODE_Checksum,
    aAttr.ulDeviceDesc,
    ulFlashStartOffset,
    ulFlashEndOffset,
  }
  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)

  if ulValue==0 then
    strHashBin = self:read_image(tPlugin, aAttr.ulParameter+0x20, 20, fnCallbackProgress)
  end

  return ulValue == 0, strHashBin
end



-- Determines the smallest interval of sectors which has to be
-- erased in order to erase ulStartAdr to ulEndAdr-1.
-- returns nil if the call fails.
function Flasher:getEraseArea(tPlugin, aAttr, ulStartAdr, ulEndAdr, fnCallbackMessage, fnCallbackProgress)
  local ulEraseStart
  local ulEraseEnd

  local aulParameter =
  {
    self.OPERATION_MODE_GetEraseArea,      -- operation mode: get erase area
    aAttr.ulDeviceDesc,                    -- data block for the device description
    ulStartAdr,
    ulEndAdr
  }

  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  if ulValue==0 then
    ulEraseStart = tPlugin:read_data32(aAttr.ulParameter+0x18)
    ulEraseEnd = tPlugin:read_data32(aAttr.ulParameter+0x1c)
  end

  return ulEraseStart, ulEraseEnd
end



-- get the flash size via getEraseArea
function Flasher:getFlashSize(tPlugin, aAttr, fnCallbackMessage, fnCallbackProgress)
  local ulEraseStart, ulEraseEnd = self:getEraseArea(tPlugin, aAttr, 0, 0xffffffff, fnCallbackMessage, fnCallbackProgress)
  return ulEraseEnd
end




-- Checks if the area from ulEraseStart to ulEraseEnd is 0xff.
-- TODO: return nil if the call fails (e.g. because ulEraseEnd is too large)
function Flasher:isErased(tPlugin, aAttr, ulEraseStart, ulEraseEnd, fnCallbackMessage, fnCallbackProgress)
  local fIsErased = false

  local aulParameter =
  {
    self.OPERATION_MODE_IsErased,          -- operation mode: isErased
    aAttr.ulDeviceDesc,                    -- data block for the device description
    ulEraseStart,
    ulEraseEnd
  }

  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  if ulValue==0 then
    ulValue = tPlugin:read_data32(aAttr.ulParameter+0x08)
    fIsErased = (ulValue==0xff)
  end

  return fIsErased
end



-- Erase an area in the flash.
-- The start and end addresses must be aligned to sector boundaries as
-- set by getEraseArea.
function Flasher:erase(tPlugin, aAttr, ulEraseStart, ulEraseEnd, fnCallbackMessage, fnCallbackProgress)
  local aulParameter =
  {
    self.OPERATION_MODE_Erase,                          -- operation mode: erase
    aAttr.ulDeviceDesc,                            -- data block for the device description
    ulEraseStart,
    ulEraseEnd
  }
  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  return ulValue == 0
end



-- Easy erase.
-- A combination of GetEraseArea, IsErased and Erase.
-- NOTE: This is an equivalent of the eraseArea function (see below) for
--       environments without scripting capabilities. This function exists
--       just for the sake of a complete API.
function Flasher:easy_erase(tPlugin, aAttr, ulEraseStart, ulEraseEnd, fnCallbackMessage, fnCallbackProgress)
  local aulParameter =
  {
    self.OPERATION_MODE_EasyErase,                      -- operation mode: easy erase
    aAttr.ulDeviceDesc,                            -- data block for the device description
    ulEraseStart,
    ulEraseEnd
  }
  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  return ulValue == 0
end




-----------------------------------------------------------------------------
-- erase an area:
-- check if the area is already erased and erase only if it isn't empty.
-- ulSize = 0xffffffff to erase from ulDeviceOffset to end of chip
--
-- OK:
-- The area is empty, no erase necessary.
-- Area erased
--
-- Error messages:
-- getEraseArea failed!
-- Failed to check if the area is erased!
-- getEraseArea failed!
-- Failed to erase the area! (Failure during erase)
-- Failed to erase the area! (isErased check failed)


function Flasher:eraseArea(tPlugin, aAttr, ulDeviceOffset, ulSize, fnCallbackMessage, fnCallbackProgress)
  fnCallbackProgress = fnCallbackProgress or self.fnProgressDefault
  local fIsErased
  local ulEndOffset
  local ulEraseStart,ulEraseEnd

  -- If length = 0xffffffff we get the erase area now in order to detect the flash size.
  if ulSize == 0xffffffff then
    ulEndOffset = ulSize
    ulEraseStart,ulEraseEnd = self:getEraseArea(tPlugin, aAttr, ulDeviceOffset, ulEndOffset, fnCallbackMessage, self.fnProgressDefault)
    if not (ulEraseStart and ulEraseEnd) then
      return false, "getEraseArea failed!"
    end

    ulEndOffset = ulEraseEnd
  else
    ulEndOffset = ulDeviceOffset + ulSize
  end

  print(string.format("Area:  [0x%08x, 0x%08x[", ulDeviceOffset, ulEndOffset))

  -- The total number of bytes to process is 3x the erase area.
  local ulProgressStageOffset = ulEndOffset - ulDeviceOffset
  local ulProgressTotal = 3 * ulProgressStageOffset

  print("Checking if the area is already empty")
  local fnProgressStage1 = function(ulCnt, ulMax) return fnCallbackProgress(ulCnt, ulProgressTotal) end
  fIsErased = self:isErased(tPlugin, aAttr, ulDeviceOffset, ulEndOffset, fnCallbackMessage, fnProgressStage1)

  if fIsErased==nil then
    return false, "Failed to check if the area is erased!"
  elseif fIsErased==true then
    return true, "The area is empty, no erase necessary."
  else
    -- Get the erase area unless we have already gotten it.
    if not (ulEraseStart and ulEraseEnd) then
      ulEraseStart,ulEraseEnd = self:getEraseArea(tPlugin, aAttr, ulDeviceOffset, ulEndOffset, fnCallbackMessage, self.fnProgressDefault)
      if not (ulEraseStart and ulEraseEnd) then
        return false, "getEraseArea failed!"
      end
    end

    print("Erasing flash")
    print(string.format("Erase: [0x%08x, 0x%08x[", ulEraseStart, ulEraseEnd))

    local fnProgressStage2 = function(ulCnt, ulMax) return fnCallbackProgress(ulCnt+ulProgressStageOffset, ulProgressTotal) end
    fIsErased = self:erase(tPlugin, aAttr, ulEraseStart, ulEraseEnd, fnCallbackMessage, fnProgressStage2)
    if fIsErased~=true then
      return false, "Failed to erase the area! (Failure during erase)"
    else
      print("Checking if the area has been erased")
      local fnProgressStage3 = function(ulCnt, ulMax) return fnCallbackProgress(ulCnt+2*ulProgressStageOffset, ulProgressTotal) end
      fIsErased = self:isErased(tPlugin, aAttr,  ulDeviceOffset, ulEndOffset, fnCallbackMessage, fnProgressStage3)
      if fIsErased~=true then
        return false, "Failed to erase the area! (isErased check failed)"
      end
    end
  end
  return true, "Area erased"
end




-----------------------------------------------------------------------------
-- flash data in chunks

-- Error messages:
-- Failed to flash data!

-- Ok:
-- Image flashed.

function Flasher:flashArea(tPlugin, aAttr, ulDeviceOffset, strData, fnCallbackMessage, fnCallbackProgress)
  fnCallbackProgress = fnCallbackProgress or self.fnProgressDefault
  local fOk
  local ulDataByteSize = strData:len()
  local ulDataOffset = 0
  local ulProgressOffset = 0
  local ulBufferAdr = aAttr.ulBufferAdr
  local ulBufferLen = aAttr.ulBufferLen
  local ulChunkSize
  local strChunk

  -- The total number of bytes to process is 2x the flash area.
  local ulProgressTotal = 2 * ulDataByteSize

  while ulDataOffset<ulDataByteSize do
    -- Extract the next chunk.
    -- Required for netx 90 Intflash, does not hurt in other cases:
    -- Align the end of the chunk to a 16 byte boundary, unless this is the last chunk.
    -- Note: Additionally, ulDeviceOffset must also be a multiple of 16 bytes.
    local ulEnd = ulDataOffset+ulBufferLen
    if ulEnd < ulDataByteSize then
      ulEnd = ulEnd - (ulEnd % 16) 
    end
    strChunk = strData:sub(ulDataOffset+1, ulEnd)
    ulChunkSize = strChunk:len()

    -- Download the chunk to the buffer.
    local fnProgressStage1 = function(ulCnt, ulMax) return fnCallbackProgress(ulCnt+ulProgressOffset, ulProgressTotal) end
    self:write_image(tPlugin, ulBufferAdr, strChunk, fnProgressStage1)
    ulProgressOffset = ulProgressOffset + ulChunkSize

    -- Flash the chunk.
    print(string.format("flashing offset 0x%08x-0x%08x.", ulDeviceOffset, ulDeviceOffset+ulChunkSize))
    local fnProgressStage2 = function(ulCnt, ulMax) return fnCallbackProgress(ulCnt+ulProgressOffset, ulProgressTotal) end
    fOk = self:flash(tPlugin, aAttr, ulDeviceOffset, ulChunkSize, ulBufferAdr, fnCallbackMessage, fnProgressStage2)
    if not fOk then
      return false, "Failed to flash data!"
    end
    ulProgressOffset = ulProgressOffset + ulChunkSize

    -- Increase pointers.
    ulDataOffset = ulDataOffset + ulChunkSize
    ulDeviceOffset = ulDeviceOffset + ulChunkSize
  end

  return true, "Image flashed."
end



-----------------------------------------------------------------------------
-- verify data in chunks

-- Ok:
-- The data in the flash is equal to the input file.

-- Error messages:
-- Differences were found.

function Flasher:verifyArea(tPlugin, aAttr, ulDeviceOffset, strData, fnCallbackMessage, fnCallbackProgress)
  local fOk
  local ulDataByteSize = strData:len()
  local ulDataOffset = 0
  local ulBufferAdr = aAttr.ulBufferAdr
  local ulBufferLen = aAttr.ulBufferLen
  local ulChunkSize
  local strChunk

  while ulDataOffset<ulDataByteSize do
    -- Extract the next chunk.
    strChunk = strData:sub(ulDataOffset+1, ulDataOffset+ulBufferLen)
    ulChunkSize = strChunk:len()

    -- Download the chunk to the buffer.
    self:write_image(tPlugin, ulBufferAdr, strChunk, fnCallbackProgress)

    -- Verify the chunk.
    print(string.format("verifying offset 0x%08x-0x%08x.", ulDeviceOffset, ulDeviceOffset+ulChunkSize))
    fOk = self:verify(tPlugin, aAttr, ulDeviceOffset, ulDeviceOffset + ulChunkSize, ulBufferAdr, fnCallbackMessage, fnCallbackProgress)
    if not fOk then
      return false, "Differences were found."
    end

    -- Increase pointers.
    ulDataOffset = ulDataOffset + ulChunkSize
    ulDeviceOffset = ulDeviceOffset + ulChunkSize
  end

  return true, "The data in the flash is equal to the input file."
end






-----------------------------------------------------------------------------
-- Read data in chunks
-- size = 0xffffffff to read from ulDeviceOffset to end of device

-- Ok:
-- Read successful.

-- Error messages:
-- Could not determine the flash size!
-- Error while reading from flash!
-- Error while reading from RAM buffer!

function Flasher:readArea(tPlugin, aAttr, ulDeviceOffset, ulDataByteSize, fnCallbackMessage, fnCallbackProgress)
  local fOk
  local ulSize = ulDataByteSize
  local ulBufferAddr = aAttr.ulBufferAdr
  local ulBufferLen = aAttr.ulBufferLen
  local strChunk
  local ulChunkSize
  local astrChunks = {}

  if ulSize == 0xffffffff then 
    ulSize = self:getFlashSize(tPlugin, aAttr, fnCallbackMessage, fnCallbackProgress)
    if ulSize then
      print(string.format("Flash size: 0x%08x bytes", ulSize))
      ulSize = ulSize - ulDeviceOffset
    else
      return nil, "Could not determine the flash size!"
    end
  end

  while ulSize>0 do
    -- determine chunk size
    ulChunkSize = math.min(ulSize, ulBufferLen)

    -- Read chunk into buffer
    print(string.format("reading flash offset 0x%08x-0x%08x.", ulDeviceOffset, ulDeviceOffset+ulChunkSize))
    fOk = self:read(tPlugin, aAttr, ulDeviceOffset, ulDeviceOffset + ulChunkSize, ulBufferAddr, fnCallbackMessage, fnCallbackProgress)
    if not fOk then
      return nil, "Error while reading from flash!"
    end

    -- Read the buffer 
    strChunk = self:read_image(tPlugin, ulBufferAddr, ulChunkSize, fnCallbackProgress)
    if not strChunk then
      return nil, "Error while reading from RAM buffer!"
    end

    table.insert(astrChunks, strChunk)

    ulDeviceOffset = ulDeviceOffset + ulChunkSize
    ulSize = ulSize - ulChunkSize
  end

  local strBin = table.concat(astrChunks)
  local strMsg = string.format("%d bytes read.", ulDataByteSize)
  return strBin, strMsg
end




--------------------------------------------------------------------------
-- Calculate the SHA1 hash of an area of an area in the flash.
-- size = 0xffffffff to read from ulDeviceOffset to end of device
--
-- Returns the hash as a binary string or nil and an error message.
-- 
-- Ok:
-- "Checksum calculated."
--
-- Error messages:
-- Could not determine the flash size!
-- "Error while calculating SHA1 hash"
--
--------------------------------------------------------------------------

function Flasher:hashArea(tPlugin, aAttr, ulDeviceOffset, ulDataByteSize, fnCallbackMessage, fnCallbackProgress)
  local ulDeviceEndOffset
  if ulDataByteSize == 0xffffffff then 
    local ulDeviceSize = self:getFlashSize(tPlugin, aAttr, fnCallbackMessage, fnCallbackProgress)
    if ulDeviceSize then
      print(string.format("Flash size: 0x%08x bytes", ulDeviceSize))
      ulDeviceEndOffset = ulDeviceSize
    else
      return nil, "Could not determine the flash size!"
    end
  else
    ulDeviceEndOffset = ulDeviceOffset + ulDataByteSize
  end

  local fOk, strFlashHashBin = self:hash(tPlugin, aAttr, ulDeviceOffset, ulDeviceEndOffset, fnCallbackMessage, fnCallbackProgress)
  if fOk~=true then
    return nil, "Error while calculating SHA1 hash."
  else
    return strFlashHashBin, "Checksum calculated."
  end
end


--------------------------------------------------------------------------
-- simple_flasher_string
-- This is a simple routine to flash the data in a string.
-- Load file from strDataFileName and write it to offset 0
-- Raise an error in case of any errors
--
--   tPlugin
--   strDataFileName
--
--   tBus
--   ulUnit
--   ulChipSelect
--
--   strFlasherPrefix
--   fnCallbackProgress
--   fnCallbackMessage
--------------------------------------------------------------------------

function Flasher:simple_flasher_string(tPlugin, strData, tBus, ulUnit, ulChipSelect, strFlasherPrefix, fnCallbackProgress, fnCallbackMessage)
  strFlasherPrefix = strFlasherPrefix or ""

  local fOk
  local strMsg
  local ulDeviceOffset = 0

  -- Download the binary.
  local aAttr = self:download(tPlugin, strFlasherPrefix, fnCallbackProgress)

  -- Detect the device.
  fOk = self:detect(tPlugin, aAttr, tBus, ulUnit, ulChipSelect, fnCallbackMessage, fnCallbackProgress)
  if fOk~=true then
    error("Failed to detect the device!")
  end

  fOk, strMsg = self:eraseArea(tPlugin, aAttr, ulDeviceOffset, strData:len(), fnCallbackMessage, fnCallbackProgress)
  print(strMsg)
  assert(fOk, strMsg or "Error while erasing area")

  fOk, strMsg = self:flashArea(tPlugin, aAttr, ulDeviceOffset, strData, fnCallbackMessage, fnCallbackProgress)
  print(strMsg)
  assert(fOk, strMsg or "Error while programming area")

  print("*** Flashing ok ***")
end



--------------------------------------------------------------------------
-- simple_flasher
-- This is a simple routine to flash one file.
-- Load file from strDataFileName and write it to offset 0
-- Raise an error in case of any errors
--
--   tPlugin
--   strDataFileName
--
--   tBus
--   ulUnit
--   ulChipSelect
--
--   strFlasherPrefix
--   fnCallbackProgress
--   fnCallbackMessage
--------------------------------------------------------------------------

function Flasher:simple_flasher(tPlugin, strDataFileName, tBus, ulUnit, ulChipSelect, strFlasherPrefix, fnCallbackProgress, fnCallbackMessage)
  -- Load the data.
  local tFile, strMsg = io.open(strDataFileName, 'rb')
  if tFile==nil then
    error(string.format('Failed to open file "%s" for reading: %s', strPath, strMsg))
  end
  local strData = tFile:read('*a')
  tFile:close()

  self:simple_flasher_string(tPlugin, strData, tBus, ulUnit, ulChipSelect, strFlasherPrefix, fnCallbackProgress, fnCallbackMessage)
end



--------------------------------------------------------------------------
-- SPI debug interface
--------------------------------------------------------------------------

function Flasher:sdi_init(tPlugin, aAttr, ulUnit, ulChipSelect, ulSpeed_kHz, fnCallbackProgress, fnCallbackMessage)
  local ulIdleCfg = self.MSK_SQI_CFG_IDLE_IO1_OE + self.MSK_SQI_CFG_IDLE_IO1_OUT
                  + self.MSK_SQI_CFG_IDLE_IO2_OE + self.MSK_SQI_CFG_IDLE_IO2_OUT
                  + self.MSK_SQI_CFG_IDLE_IO3_OE + self.MSK_SQI_CFG_IDLE_IO3_OUT

  local aulParameter =
  {
    self.OPERATION_MODE_SpiMacroPlayer,   -- operation mode: SPI macro player
    self.SMC_INITIALIZE,                  -- Command: initialize
    aAttr.ulDeviceDesc,                   -- free space for the SPI configuration
    ulUnit,                               -- the SPI unit
    ulChipSelect,                         -- the SPI chip select
    ulSpeed_kHz,                          -- the speed in kHz (1000 -> 1MHz)
    ulSpeed_kHz,                          -- the maximum kHz
    ulIdleCfg,                            -- idle configuration
    3,                                    -- mode
    0xffffffff                            -- MMIO configuration
  }
  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  return ulValue == 0
end



function Flasher:sdi_chip_select(tPlugin, aAttr, uiActive, fnCallbackProgress, fnCallbackMessage)
  local ulValue
  if tonumber(uiActive)==0 then
    ulValue = 0
  else
    ulValue = 1
  end

  local aulParameter =
  {
    self.OPERATION_MODE_SpiMacroPlayer,   -- operation mode: SPI macro player
    self.SMC_CHIP_SELECT,                 -- Command: chip select
    aAttr.ulDeviceDesc,                   -- the SPI configuration
    ulValue,                              -- chip select
  }
  ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  return ulValue == 0
end



function Flasher:sdi_exchange_data(tPlugin, aAttr, strData, fnCallbackProgress, fnCallbackMessage)
  local strRxData
  local sizData = string.len(strData)

  local ulTxBuffer = aAttr.ulBufferAdr
  local ulRxBuffer = aAttr.ulBufferAdr + sizData

  -- Download the data.
  self:write_image(tPlugin, ulTxBuffer, strData, fnCallbackProgress)

  local aulParameter =
  {
    self.OPERATION_MODE_SpiMacroPlayer,   -- operation mode: SPI macro player
    self.SMC_EXCHANGE_DATA,               -- Command: exchange data
    aAttr.ulDeviceDesc,                   -- the SPI configuration
    ulTxBuffer,
    ulRxBuffer,
    sizData
  }
  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  if ulValue==0 then
    strRxData = self:read_image(tPlugin, ulRxBuffer, sizData, fnCallbackProgress)
  end

  return strRxData
end


function Flasher:sdi_send_data(tPlugin, aAttr, strData, fnCallbackProgress, fnCallbackMessage)
  local sizData = string.len(strData)

  local ulTxBuffer = aAttr.ulBufferAdr

  -- Download the data.
  self:write_image(tPlugin, ulTxBuffer, strData, fnCallbackProgress)

  local aulParameter =
  {
    self.OPERATION_MODE_SpiMacroPlayer,   -- operation mode: SPI macro player
    self.SMC_SEND_DATA,                   -- Command: send data
    aAttr.ulDeviceDesc,                   -- the SPI configuration
    ulTxBuffer,
    sizData
  }

  local ulValue = self:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)

  return ulValue == 0
end


function Flasher:sdi_receive_data(tPlugin, aAttr, sizData, fnCallbackProgress, fnCallbackMessage)
  local strRxData
  local ulRxBuffer = aAttr.ulBufferAdr

  local aulParameter =
  {
    self.OPERATION_MODE_SpiMacroPlayer,   -- operation mode: SPI macro player
    self.SMC_RECEIVE_DATA,                -- Command: receive data
    aAttr.ulDeviceDesc,                   -- the SPI configuration
    ulRxBuffer,
    sizData
  }

  local ulValue = Flasher:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)
  if ulValue==0 then
    strRxData = Flasher:read_image(tPlugin, ulRxBuffer, sizData, fnCallbackProgress)
  end

  return strRxData
end


function Flasher:sdi_idle_bytes(tPlugin, aAttr, sizIdleBytes, fnCallbackProgress, fnCallbackMessage)
  local aulParameter =
  {
    self.OPERATION_MODE_SpiMacroPlayer,   -- operation mode: SPI macro player
    self.SMC_SEND_IDLE_BYTES,             -- Command: send idle bytes
    aAttr.ulDeviceDesc,                   -- the SPI configuration
    sizIdleBytes
  }
  local ulValue = Flasher:callFlasher(tPlugin, aAttr, aulParameter, fnCallbackMessage, fnCallbackProgress)

  return ulValue == 0
end


return Flasher
